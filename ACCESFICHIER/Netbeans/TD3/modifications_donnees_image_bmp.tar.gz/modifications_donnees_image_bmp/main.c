/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: mrocher
 *
 * Created on 1 février 2018, 09:22
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct 
{
    unsigned char signature[2];
    unsigned char tailleFichier;
    unsigned char reserve;
    unsigned char adresseImg;
}enTeteFichierBmp;//14

typedef struct
{
    unsigned char tailleEnTete;
    unsigned char largeur;
    unsigned char hauteur;
    unsigned short int nbPlan;
    unsigned short int bitParPixel;
    unsigned int typeCompression;
    unsigned int tailleImage;
    unsigned int resolutionHorizontale;
    unsigned int resolutionVerticale;
    unsigned int nbCouleursUtilisees;
    unsigned int nbCouleurImportantes;
}enTeteImageBmp;//40

typedef struct 
{
    unsigned char b;
    unsigned char g;
    unsigned char r;
    unsigned char a;
}couleur; //4


int main(int argc, char** argv) {

    
    //ouverture du fichier
    FILE *fic;
    int retour;
    int i;
    
    fic=fopen("/home/USERS/ELEVES/SNIR2017/imgBMP/plasma.bmp","r");
   
    //lecture du fichier
    
    
    // fermeture du fichier 
    
    
    return (EXIT_SUCCESS);
}