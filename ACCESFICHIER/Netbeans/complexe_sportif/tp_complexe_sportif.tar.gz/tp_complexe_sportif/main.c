/***************************************************************************
 * programme principal de gestion de centre sportif
 ***************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "foncCentre.h"

int main( int argc, char *argv[] )
{
    typeAdherent *tabAdherents[MAXADHERENT];
    int nbAdherents;
    char choix;
    int numeroAdherent;
    int indiceAdherent;
    int i;

    nbAdherents = 0;

    do
    {
        afficheMenu(nbAdherents);
        scanf(" %c",&choix);

        switch (choix)
        {
            case 'A':
            nbAdherents=ajouteAdherent(tabAdherents,nbAdherents);
            break;
            case 'S':
            printf("numero de la carte de l'adhérent : ");
            scanf("%d",&numeroAdherent);
            nbAdherents=supprimerAdherent(tabAdherents,numeroAdherent,nbAdherents);
            break;
            case 'M':
            printf("numero de la carte de l'adhérent : ");
            scanf("%d",&numeroAdherent);
            break;
            case 'V':
            printf("numero de la carte de l'adhérent : ");
            scanf("%d",&numeroAdherent);
            // recherche de l'indice correspondant au numero d'adherent
            indiceAdherent=getIndice(tabAdherents,nbAdherents,numeroAdherent);
            if (indiceAdherent!=-1)
            {
                afficheUnAdherent(tabAdherents[indiceAdherent]);
            }
            else
            {
                printf("le numéro que vous avez donné ne correspond à aucun adhérent connu\n");
            }

            break;
            case 'L':
                afficheAdherent(tabAdherents,nbAdherents);
            break;
            case 'E':
                while (nbAdherents!=0)
                {
                    nbAdherents=supprimerAdherent(tabAdherents,tabAdherents[i]->nroCarte,nbAdherents);
                }
                break;
            case 'D':
                sauvegardeAdherents(tabAdherents, nbAdherents);
                break;
            case 'C':
                nbAdherents=chargeAdherent(tabAdherents);
                break;
        }

    }while(choix!='Q');

	return EXIT_SUCCESS;
}
